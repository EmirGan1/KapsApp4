import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calculator, 
  Trophy, 
  AlertTriangle, 
  Moon, 
  Sun, 
  Sliders, 
  Sparkles, 
  Info, 
  CheckCircle2, 
  XCircle,
  HelpCircle
} from 'lucide-react';
import { initialSubjects } from './data';
import { Subject } from './types';

export default function App() {
  const [subjects, setSubjects] = useState<Subject[]>(initialSubjects);
  const [corePoints, setCorePoints] = useState<number>(0);
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [showSummaryModal, setShowSummaryModal] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'calculator' | 'boundaries'>('calculator');

  // Load theme preference
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Handle score updates for papers
  const handlePaperScoreChange = (subjectId: string, paperId: string, value: string) => {
    const numValue = value === '' ? '' : Math.max(0, Number(value));
    setSubjects(prev => prev.map(sub => {
      if (sub.id !== subjectId) return sub;
      return {
        ...sub,
        papers: sub.papers.map(p => {
          if (p.id !== paperId) return p;
          // cap at maxScore if maxScore is a number
          const max = typeof p.maxScore === 'number' ? p.maxScore : 999;
          const clamped = typeof numValue === 'number' ? Math.min(numValue, max) : '';
          return { ...p, achievedScore: clamped };
        })
      };
    }));
  };

  // Handle max score updates for papers
  const handlePaperMaxChange = (subjectId: string, paperId: string, value: string) => {
    const numValue = value === '' ? '' : Math.max(1, Number(value));
    setSubjects(prev => prev.map(sub => {
      if (sub.id !== subjectId) return sub;
      return {
        ...sub,
        papers: sub.papers.map(p => {
          if (p.id !== paperId) return p;
          return { ...p, maxScore: numValue };
        })
      };
    }));
  };

  // Handle IA changes
  const handleIAChange = (subjectId: string, field: 'achievedScore' | 'maxScore' | 'enabled', value: any) => {
    setSubjects(prev => prev.map(sub => {
      if (sub.id !== subjectId) return sub;
      const currentIA = sub.ia;
      let updatedValue = value;
      if (field === 'achievedScore' || field === 'maxScore') {
        updatedValue = value === '' ? '' : Math.max(0, Number(value));
        if (field === 'achievedScore' && typeof currentIA.maxScore === 'number') {
          updatedValue = Math.min(updatedValue, currentIA.maxScore);
        }
      }
      return {
        ...sub,
        ia: { ...currentIA, [field]: updatedValue }
      };
    }));
  };

  // Calculate subject grade & percentage
  const subjectCalculations = useMemo(() => {
    return subjects.map(sub => {
      // 1. Calculate exam papers percentage
      let totalPaperAchieved = 0;
      let totalPaperMax = 0;
      sub.papers.forEach(p => {
        totalPaperAchieved += Number(p.achievedScore) || 0;
        totalPaperMax += Number(p.maxScore) || 1;
      });
      const paperPercentage = totalPaperMax > 0 ? (totalPaperAchieved / totalPaperMax) * 100 : 0;

      let finalPercentage = paperPercentage;
      let iaPercentage = 0;

      if (sub.ia.enabled && sub.ia.maxScore !== '' && sub.ia.maxScore > 0) {
        const iaAchieved = Number(sub.ia.achievedScore) || 0;
        iaPercentage = (iaAchieved / Number(sub.ia.maxScore)) * 100;
        const iaWeight = sub.ia.weight / 100;
        const paperWeight = 1 - iaWeight;
        finalPercentage = (paperPercentage * paperWeight) + (iaPercentage * iaWeight);
      }

      const roundedPercentage = Math.round(finalPercentage * 10) / 10;
      const boundary = sub.boundaries.find(b => roundedPercentage >= b.min);
      const grade = boundary ? boundary.grade : 1;

      // What-if IA projections if IA is NOT enabled
      let projections = null;
      if (!sub.ia.enabled) {
        const iaWeight = sub.ia.weight / 100;
        const paperWeight = 1 - iaWeight;
        const currentPaperContribution = paperPercentage * paperWeight;

        // Low IA (~35%), Avg IA (~65%), High IA (~88%)
        const lowIAPct = 35;
        const avgIAPct = 65;
        const highIAPct = 90;

        const lowTotal = currentPaperContribution + (lowIAPct * iaWeight);
        const avgTotal = currentPaperContribution + (avgIAPct * iaWeight);
        const highTotal = currentPaperContribution + (highIAPct * iaWeight);

        const getGradeForPct = (pct: number) => {
          const b = sub.boundaries.find(item => pct >= item.min);
          return b ? b.grade : 1;
        };

        // Calculate minimum raw IA score needed for next grade boundary
        const nextBoundary = sub.boundaries.slice().reverse().find(b => b.grade > grade);
        let minIANeeded = null;
        if (nextBoundary && sub.ia.maxScore !== '' && Number(sub.ia.maxScore) > 0) {
          // requiredTotal = nextBoundary.min
          // requiredTotal = paperPercentage * paperWeight + (IA_pct * iaWeight)
          // IA_pct = (requiredTotal - paperPercentage * paperWeight) / iaWeight
          const requiredIAPct = (nextBoundary.min - currentPaperContribution) / iaWeight;
          const rawNeeded = Math.ceil((requiredIAPct / 100) * Number(sub.ia.maxScore));
          minIANeeded = {
            targetGrade: nextBoundary.grade,
            raw: Math.max(0, Math.min(rawNeeded, Number(sub.ia.maxScore)))
          };
        }

        projections = {
          low: getGradeForPct(lowTotal),
          avg: getGradeForPct(avgTotal),
          high: getGradeForPct(highTotal),
          minIANeeded
        };
      }

      return {
        id: sub.id,
        percentage: roundedPercentage,
        grade,
        projections
      };
    });
  }, [subjects]);

  const totalSubjectGrade = subjectCalculations.reduce((sum, item) => sum + item.grade, 0);
  const finalScore = totalSubjectGrade + corePoints;
  const isPassing = finalScore >= 24;

  // Grade badge styling helper
  const getGradeStyle = (grade: number) => {
    switch (grade) {
      case 7:
        return 'bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 text-white shadow-purple-500/30 ring-2 ring-purple-400/50';
      case 6:
        return 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-cyan-500/20';
      case 5:
        return 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-emerald-500/20';
      case 4:
        return 'bg-gradient-to-r from-amber-500 to-yellow-600 text-white shadow-amber-500/20';
      case 3:
        return 'bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-orange-500/20';
      default:
        return 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-red-500/20';
    }
  };

  const getProgressBarColor = (grade: number) => {
    switch (grade) {
      case 7: return 'from-purple-500 to-pink-500';
      case 6: return 'from-cyan-500 to-teal-500';
      case 5: return 'from-emerald-500 to-green-500';
      case 4: return 'from-amber-400 to-yellow-500';
      case 3: return 'from-orange-400 to-amber-500';
      default: return 'from-rose-500 to-red-600';
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-[#0B0F19] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'} font-sans pb-24`}>
      
      {/* Sticky Top Header / Navbar */}
      <header className={`sticky top-0 z-40 backdrop-blur-xl border-b transition-colors ${darkMode ? 'bg-[#0B0F19]/85 border-slate-800' : 'bg-white/85 border-slate-200'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/25 text-white">
              <Calculator size={24} />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                IB Puan Hesaplayıcı
              </h1>
              <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Gelişmiş Sınav, IA ve Diploma Simülatörü
              </p>
            </div>
          </div>

          {/* Navigation / Actions */}
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center bg-slate-800/10 dark:bg-slate-800/50 p-1 rounded-xl border border-slate-700/20">
              <button
                onClick={() => setActiveTab('calculator')}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'calculator' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
              >
                Hesap Makinesi
              </button>
              <button
                onClick={() => setActiveTab('boundaries')}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'boundaries' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
              >
                Not Sınırları (Boundaries)
              </button>
            </div>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2.5 rounded-xl border transition-all ${darkMode ? 'bg-slate-800 border-slate-700 text-amber-400 hover:bg-slate-700' : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'}`}
              title="Tema Değiştir"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </div>
      </header>

      {/* Sticky Summary Banner */}
      <div className={`sticky top-20 z-30 border-b shadow-lg transition-colors ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white/90 border-slate-200'} backdrop-blur-md`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Total Score & Circular Progress */}
          <div className="flex items-center gap-6">
            <div className="relative flex items-center justify-center">
              <svg className="w-16 h-16 transform -rotate-90">
                <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="6" className={darkMode ? 'text-slate-800' : 'text-slate-200'} fill="transparent" />
                <circle 
                  cx="32" cy="32" r="28" 
                  stroke="currentColor" 
                  strokeWidth="6" 
                  className={isPassing ? 'text-emerald-500' : 'text-rose-500'} 
                  fill="transparent" 
                  strokeDasharray={175.9}
                  strokeDashoffset={175.9 - (175.9 * Math.min(finalScore, 45)) / 45}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-xl font-black">{finalScore}</span>
              </div>
            </div>

            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Toplam IB Puanı</div>
              <div className="text-2xl font-black flex items-baseline gap-2">
                <span>{finalScore} <span className="text-sm font-normal text-slate-400">/ 45</span></span>
                <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  Dersler: {totalSubjectGrade} + Core: {corePoints}
                </span>
              </div>
            </div>
          </div>

          {/* Diploma Status Badge */}
          <div className="flex items-center gap-4">
            <div className={`px-4 py-2 rounded-2xl flex items-center gap-2.5 border font-bold text-sm shadow-sm ${
              isPassing 
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 animate-pulse' 
                : 'bg-rose-500/10 border-rose-500/30 text-rose-400 animate-pulse'
            }`}>
              {isPassing ? <CheckCircle2 size={18} /> : <XCircle size={18} />}
              <span>{isPassing ? 'DİPLOMA ALINDI (Geçti)' : 'KRİTİK SINIR / DİPLOMA RİSKTE (<24)'}</span>
            </div>
          </div>

          {/* Core Points Selector */}
          <div className="flex items-center gap-2 bg-slate-800/20 dark:bg-slate-800/60 p-2 rounded-2xl border border-slate-700/30">
            <span className="text-xs font-semibold text-slate-400 pl-1">Core (EE/TOK):</span>
            <div className="flex gap-1">
              {[0, 1, 2, 3].map(pt => (
                <button
                  key={pt}
                  onClick={() => setCorePoints(pt)}
                  className={`w-9 h-9 rounded-xl font-bold text-sm transition-all ${
                    corePoints === pt 
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30 scale-105' 
                      : darkMode ? 'bg-slate-800 text-slate-400 hover:bg-slate-700' : 'bg-white text-slate-700 hover:bg-slate-100 shadow-sm'
                  }`}
                >
                  +{pt}
                </button>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'calculator' ? (
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-gradient-to-r from-indigo-900/20 via-purple-900/20 to-pink-900/20 p-6 rounded-3xl border border-indigo-500/20">
              <div>
                <h2 className="text-xl font-bold mb-1">Ders Sınavları ve IA Simülatörü</h2>
                <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Her ders için sınav puanlarını kaydırarak veya yazarak girin. İsterseniz IA (Internal Assessment) puanını ekleyin veya sistemin otomatik IA senaryolarını inceleyin.
                </p>
              </div>
              <button
                onClick={() => setShowSummaryModal(true)}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-sm shadow-lg shadow-indigo-600/25 transition-all flex items-center gap-2"
              >
                <Sparkles size={16} />
                Genel Özet & Tablo
              </button>
            </div>

            {/* Subject Cards Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {subjects.map(subject => {
                const calc = subjectCalculations.find(s => s.id === subject.id)!;
                return (
                  <div 
                    key={subject.id} 
                    className={`rounded-3xl border transition-all duration-300 overflow-hidden shadow-xl flex flex-col ${
                      darkMode 
                        ? 'bg-slate-900/80 border-slate-800 hover:border-slate-700' 
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {/* Card Header */}
                    <div className={`px-6 py-4 border-b flex items-center justify-between ${darkMode ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50'}`}>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-extrabold px-2 py-0.5 rounded-md uppercase ${subject.level === 'HL' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'}`}>
                            {subject.level}
                          </span>
                          <h3 className="text-lg font-bold">{subject.name}</h3>
                        </div>
                        <span className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          Ağırlıklı Yüzde: <strong className={darkMode ? 'text-slate-200' : 'text-slate-800'}>%{calc.percentage}</strong>
                        </span>
                      </div>

                      {/* Grade Badge */}
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-2xl shadow-lg transition-transform hover:scale-105 ${getGradeStyle(calc.grade)}`}>
                        {calc.grade}
                      </div>
                    </div>

                    {/* Card Body - Papers & IA */}
                    <div className="p-6 space-y-6 flex-1">
                      
                      {/* Papers */}
                      <div className="space-y-4">
                        <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                          <Sliders size={14} /> Sınavlar (Papers)
                        </div>
                        
                        {subject.papers.map(paper => {
                          const max = typeof paper.maxScore === 'number' ? paper.maxScore : 100;
                          const val = typeof paper.achievedScore === 'number' ? paper.achievedScore : 0;
                          return (
                            <div key={paper.id} className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-200'} space-y-3`}>
                              <div className="flex justify-between items-center text-sm">
                                <span className="font-semibold">{paper.name}</span>
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="number"
                                    min="0"
                                    value={paper.achievedScore}
                                    onChange={(e) => handlePaperScoreChange(subject.id, paper.id, e.target.value)}
                                    className={`w-16 px-2 py-1 text-center font-bold rounded-lg border text-sm ${darkMode ? 'bg-slate-900 border-slate-700 text-indigo-400' : 'bg-white border-slate-300 text-indigo-600'}`}
                                    placeholder="0"
                                  />
                                  <span className="text-slate-400">/</span>
                                  <input
                                    type="number"
                                    min="1"
                                    value={paper.maxScore}
                                    onChange={(e) => handlePaperMaxChange(subject.id, paper.id, e.target.value)}
                                    className={`w-14 px-2 py-1 text-center text-xs font-semibold rounded-lg border ${darkMode ? 'bg-slate-900 border-slate-700 text-slate-400' : 'bg-white border-slate-300 text-slate-600'}`}
                                    title="Maksimum Puan"
                                  />
                                </div>
                              </div>

                              {/* Range Slider */}
                              <input
                                type="range"
                                min="0"
                                max={max}
                                value={val}
                                onChange={(e) => handlePaperScoreChange(subject.id, paper.id, e.target.value)}
                                className="w-full h-2 bg-slate-700/30 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                              />
                            </div>
                          );
                        })}
                      </div>

                      {/* Internal Assessment (IA) Section */}
                      <div className={`p-4 rounded-2xl border transition-colors ${subject.ia.enabled ? (darkMode ? 'bg-indigo-950/20 border-indigo-500/40' : 'bg-indigo-50/60 border-indigo-200') : (darkMode ? 'bg-slate-800/20 border-slate-800' : 'bg-slate-100/50 border-slate-200')}`}>
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm">Internal Assessment (IA)</span>
                            <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 font-semibold">
                              %{subject.ia.weight} Ağırlık
                            </span>
                          </div>
                          <button
                            onClick={() => handleIAChange(subject.id, 'enabled', !subject.ia.enabled)}
                            className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
                              subject.ia.enabled 
                                ? 'bg-indigo-600 text-white shadow-md' 
                                : darkMode ? 'bg-slate-800 text-slate-400 hover:bg-slate-700' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                            }`}
                          >
                            {subject.ia.enabled ? 'IA Dahil (Aktif)' : 'IA Henüz Belli Değil'}
                          </button>
                        </div>

                        {subject.ia.enabled ? (
                          <div className="space-y-3 mt-3 pt-3 border-t border-indigo-500/20">
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-slate-400 text-xs">IA Puanı (Max: {subject.ia.maxScore})</span>
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="number"
                                  min="0"
                                  value={subject.ia.achievedScore}
                                  onChange={(e) => handleIAChange(subject.id, 'achievedScore', e.target.value)}
                                  className={`w-16 px-2 py-1 text-center font-bold rounded-lg border text-sm ${darkMode ? 'bg-slate-900 border-slate-700 text-indigo-400' : 'bg-white border-slate-300 text-indigo-600'}`}
                                  placeholder="0"
                                />
                                <span className="text-slate-400">/</span>
                                <input
                                  type="number"
                                  min="1"
                                  value={subject.ia.maxScore}
                                  onChange={(e) => handleIAChange(subject.id, 'maxScore', e.target.value)}
                                  className={`w-14 px-2 py-1 text-center text-xs font-semibold rounded-lg border ${darkMode ? 'bg-slate-900 border-slate-700 text-slate-400' : 'bg-white border-slate-300 text-slate-600'}`}
                                />
                              </div>
                            </div>
                            <input
                              type="range"
                              min="0"
                              max={typeof subject.ia.maxScore === 'number' ? subject.ia.maxScore : 25}
                              value={typeof subject.ia.achievedScore === 'number' ? subject.ia.achievedScore : 0}
                              onChange={(e) => handleIAChange(subject.id, 'achievedScore', e.target.value)}
                              className="w-full h-2 bg-slate-700/30 rounded-lg appearance-none cursor-pointer accent-purple-500"
                            />
                          </div>
                        ) : (
                          /* What-if Projections Matrix */
                          calc.projections && (
                            <div className="mt-3 space-y-2.5 pt-3 border-t border-slate-700/20 text-xs">
                              <div className="font-semibold text-slate-400 flex items-center gap-1">
                                <Info size={13} className="text-indigo-400" /> Olası IA Senaryoları (Tahmini Not):
                              </div>
                              <div className="grid grid-cols-3 gap-2 text-center">
                                <div className={`p-2 rounded-xl border ${darkMode ? 'bg-slate-800/60 border-slate-700' : 'bg-white border-slate-200'}`}>
                                  <div className="text-slate-400 text-[10px]">Düşük IA (%35)</div>
                                  <div className="font-bold text-sm text-amber-400">{calc.projections.low} / 7</div>
                                </div>
                                <div className={`p-2 rounded-xl border ${darkMode ? 'bg-slate-800/60 border-slate-700' : 'bg-white border-slate-200'}`}>
                                  <div className="text-slate-400 text-[10px]">Ortalama IA (%65)</div>
                                  <div className="font-bold text-sm text-emerald-400">{calc.projections.avg} / 7</div>
                                </div>
                                <div className={`p-2 rounded-xl border ${darkMode ? 'bg-slate-800/60 border-slate-700' : 'bg-white border-slate-200'}`}>
                                  <div className="text-slate-400 text-[10px]">Yüksek IA (%90)</div>
                                  <div className="font-bold text-sm text-purple-400">{calc.projections.high} / 7</div>
                                </div>
                              </div>
                              {calc.projections.minIANeeded && (
                                <div className="text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 px-3 py-1.5 rounded-xl font-medium flex items-center justify-between">
                                  <span>Bir üst nota ({calc.projections.minIANeeded.targetGrade}) çıkmak için:</span>
                                  <span className="font-bold text-indigo-400">Min. {calc.projections.minIANeeded.raw} / {subject.ia.maxScore} IA gerekli</span>
                                </div>
                              )}
                            </div>
                          )
                        )}
                      </div>

                    </div>

                    {/* Card Footer Progress Bar */}
                    <div className={`px-6 py-3 border-t flex flex-col gap-1.5 ${darkMode ? 'border-slate-800 bg-slate-900/60' : 'border-slate-100 bg-slate-50'}`}>
                      <div className="flex justify-between items-center text-xs font-bold">
                        <span className="text-slate-400">Not Sınırı İlerlemesi</span>
                        <span className="text-indigo-400">%{calc.percentage}</span>
                      </div>
                      <div className={`w-full h-2.5 rounded-full overflow-hidden ${darkMode ? 'bg-slate-800' : 'bg-slate-200'}`}>
                        <div 
                          className={`h-full bg-gradient-to-r ${getProgressBarColor(calc.grade)} transition-all duration-500 rounded-full`}
                          style={{ width: `${Math.min(100, Math.max(2, calc.percentage))}%` }}
                        />
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>

          </div>
        ) : (
          /* Boundaries Reference Tab */
          <div className={`rounded-3xl border p-6 md:p-8 shadow-xl ${darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h2 className="text-2xl font-black mb-4 flex items-center gap-2">
              <HelpCircle className="text-indigo-500" /> IB Not Sınırları (Grade Boundaries) Kılavuzu
            </h2>
            <p className={`text-sm mb-6 ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Uygulamanın hesaplama yaparken baz aldığı resmi ve güncel IB yüzde sınırları tablosu aşağıdadır.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className={`border-b text-xs uppercase tracking-wider ${darkMode ? 'border-slate-800 text-slate-400 bg-slate-800/40' : 'border-slate-200 text-slate-600 bg-slate-100'}`}>
                    <th className="p-4 rounded-l-xl">Ders</th>
                    <th className="p-4 text-center">Grade 7</th>
                    <th className="p-4 text-center">Grade 6</th>
                    <th className="p-4 text-center">Grade 5</th>
                    <th className="p-4 text-center">Grade 4</th>
                    <th className="p-4 text-center">Grade 3</th>
                    <th className="p-4 text-center rounded-r-xl">Grade 2 / 1</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/20 text-sm">
                  {subjects.map(sub => {
                    const getMin = (g: number) => sub.boundaries.find(b => b.grade === g)?.min || 0;
                    return (
                      <tr key={sub.id} className={`transition-colors ${darkMode ? 'hover:bg-slate-800/30' : 'hover:bg-slate-50'}`}>
                        <td className="p-4 font-bold flex items-center gap-2">
                          <span className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${sub.level === 'HL' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                            {sub.level}
                          </span>
                          {sub.name}
                        </td>
                        <td className="p-4 text-center font-bold text-purple-400">%{getMin(7)} - 100</td>
                        <td className="p-4 text-center font-semibold text-cyan-400">%{getMin(6)} - {getMin(7)-1}</td>
                        <td className="p-4 text-center font-semibold text-emerald-400">%{getMin(5)} - {getMin(6)-1}</td>
                        <td className="p-4 text-center font-semibold text-amber-400">%{getMin(4)} - {getMin(5)-1}</td>
                        <td className="p-4 text-center font-semibold text-orange-400">%{getMin(3)} - {getMin(4)-1}</td>
                        <td className="p-4 text-center font-semibold text-rose-400">&lt; %{getMin(3)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Summary Modal / Dialog */}
      <AnimatePresence>
        {showSummaryModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className={`w-full max-w-2xl rounded-3xl p-6 md:p-8 shadow-2xl border ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'}`}
            >
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold">
                    <Trophy size={20} />
                  </div>
                  <h3 className="text-xl font-black">IB Diploma Puan Özeti</h3>
                </div>
                <button
                  onClick={() => setShowSummaryModal(false)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center font-bold ${darkMode ? 'bg-slate-800 hover:bg-slate-700 text-slate-300' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'}`}
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4 mb-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-800/40 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                    <div className="text-xs text-slate-400 font-semibold">6 Ders Toplamı</div>
                    <div className="text-3xl font-black text-indigo-500 mt-1">{totalSubjectGrade} <span className="text-sm font-normal text-slate-400">/ 42</span></div>
                  </div>
                  <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-800/40 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                    <div className="text-xs text-slate-400 font-semibold">Core Points (EE/TOK)</div>
                    <div className="text-3xl font-black text-purple-500 mt-1">+{corePoints} <span className="text-sm font-normal text-slate-400">/ 3</span></div>
                  </div>
                </div>

                <div className={`p-5 rounded-2xl border flex items-center justify-between ${
                  isPassing 
                    ? (darkMode ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300' : 'bg-emerald-50 border-emerald-200 text-emerald-800') 
                    : (darkMode ? 'bg-rose-950/20 border-rose-500/30 text-rose-300' : 'bg-rose-50 border-rose-200 text-rose-800')
                }`}>
                  <div>
                    <div className="font-bold text-lg">{isPassing ? 'TEBRİKLER! DİPLOMA ALMAYA HAK KAZANDINIZ' : 'DİPLOMA KRİTİK SEVİYEDE (<24 PUAN)'}</div>
                    <div className="text-xs opacity-80 mt-0.5">Toplam Puan: {finalScore} / 45 (Geçme barajı: 24 puan)</div>
                  </div>
                  <div className="text-3xl font-black">{finalScore}</div>
                </div>

                {/* Breakdown List */}
                <div className="space-y-2 mt-4">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Ders Notu Dağılımı</div>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {subjects.map(sub => {
                      const calc = subjectCalculations.find(s => s.id === sub.id)!;
                      return (
                        <div key={sub.id} className={`flex justify-between items-center p-3 rounded-xl border text-sm ${darkMode ? 'bg-slate-800/30 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                          <span className="font-semibold">{sub.name}</span>
                          <div className="flex items-center gap-3">
                            <span className="text-xs text-slate-400">%{calc.percentage}</span>
                            <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${getGradeStyle(calc.grade)}`}>
                              {calc.grade}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowSummaryModal(false)}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl shadow-lg shadow-indigo-600/30 transition-all text-center"
              >
                Kapat ve Düzenlemeye Dön
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
