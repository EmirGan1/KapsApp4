import { Subject } from './types';

export const initialSubjects: Subject[] = [
  {
    id: 'turkish-a-sl',
    name: 'Turkish A SL',
    level: 'SL',
    boundaries: [
      { grade: 7, min: 76 },
      { grade: 6, min: 65 },
      { grade: 5, min: 53 },
      { grade: 4, min: 42 },
      { grade: 3, min: 27 },
      { grade: 2, min: 14 },
      { grade: 1, min: 0 }
    ],
    papers: [
      { id: 'p1', name: 'Paper 1', maxScore: 20, achievedScore: '' }
    ],
    ia: {
      maxScore: 25,
      achievedScore: '',
      weight: 30, // 30% IA, 70% Paper 1 (or adjustable)
      enabled: false
    }
  },
  {
    id: 'english-b-hl',
    name: 'English B HL',
    level: 'HL',
    boundaries: [
      { grade: 7, min: 85 },
      { grade: 6, min: 69 },
      { grade: 5, min: 54 },
      { grade: 4, min: 39 },
      { grade: 3, min: 25 },
      { grade: 2, min: 13 },
      { grade: 1, min: 0 }
    ],
    papers: [
      { id: 'p1', name: 'Paper 1', maxScore: 30, achievedScore: '' },
      { id: 'list', name: 'Listening', maxScore: 25, achievedScore: '' },
      { id: 'read', name: 'Reading', maxScore: 40, achievedScore: '' }
    ],
    ia: {
      maxScore: 30,
      achievedScore: '',
      weight: 20, // 20% Oral IA
      enabled: false
    }
  },
  {
    id: 'turkey-20th-sl',
    name: 'Turkey in the 20th Century SL',
    level: 'SL',
    boundaries: [
      { grade: 7, min: 70 },
      { grade: 6, min: 60 },
      { grade: 5, min: 50 },
      { grade: 4, min: 40 },
      { grade: 3, min: 27 },
      { grade: 2, min: 14 },
      { grade: 1, min: 0 }
    ],
    papers: [
      { id: 'p1', name: 'Paper 1', maxScore: 24, achievedScore: '' },
      { id: 'p2', name: 'Paper 2', maxScore: 30, achievedScore: '' }
    ],
    ia: {
      maxScore: 25,
      achievedScore: '',
      weight: 25,
      enabled: false
    }
  },
  {
    id: 'math-aa-hl',
    name: 'Math AA HL',
    level: 'HL',
    boundaries: [
      { grade: 7, min: 77 },
      { grade: 6, min: 66 },
      { grade: 5, min: 52 },
      { grade: 4, min: 40 },
      { grade: 3, min: 30 },
      { grade: 2, min: 15 },
      { grade: 1, min: 0 }
    ],
    papers: [
      { id: 'p1', name: 'Paper 1', maxScore: 110, achievedScore: '' },
      { id: 'p2', name: 'Paper 2', maxScore: 110, achievedScore: '' },
      { id: 'p3', name: 'Paper 3', maxScore: 30, achievedScore: '' }
    ],
    ia: {
      maxScore: 20,
      achievedScore: '',
      weight: 20,
      enabled: false
    }
  },
  {
    id: 'physics-sl',
    name: 'Physics SL',
    level: 'SL',
    boundaries: [
      { grade: 7, min: 71 },
      { grade: 6, min: 61 },
      { grade: 5, min: 51 },
      { grade: 4, min: 40 },
      { grade: 3, min: 28 },
      { grade: 2, min: 14 },
      { grade: 1, min: 0 }
    ],
    papers: [
      { id: 'p1a', name: 'Paper 1a', maxScore: 30, achievedScore: '' },
      { id: 'p1b', name: 'Paper 1b', maxScore: 15, achievedScore: '' },
      { id: 'p2', name: 'Paper 2', maxScore: 50, achievedScore: '' }
    ],
    ia: {
      maxScore: 24,
      achievedScore: '',
      weight: 20,
      enabled: false
    }
  },
  {
    id: 'digital-society-hl',
    name: 'Digital Society HL',
    level: 'HL',
    boundaries: [
      { grade: 7, min: 70 },
      { grade: 6, min: 60 },
      { grade: 5, min: 50 },
      { grade: 4, min: 40 },
      { grade: 3, min: 27 },
      { grade: 2, min: 14 },
      { grade: 1, min: 0 }
    ],
    papers: [
      { id: 'p1a', name: 'Paper 1a', maxScore: 40, achievedScore: '' },
      { id: 'p1b', name: 'Paper 1b', maxScore: 12, achievedScore: '' },
      { id: 'p2', name: 'Paper 2', maxScore: 24, achievedScore: '' }
    ],
    ia: {
      maxScore: 30,
      achievedScore: '',
      weight: 25,
      enabled: false
    }
  }
];
