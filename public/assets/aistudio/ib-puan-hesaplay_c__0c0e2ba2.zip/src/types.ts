export interface GradeBoundary {
  grade: number;
  min: number;
}

export interface Paper {
  id: string;
  name: string;
  maxScore: number | '';
  achievedScore: number | '';
}

export interface InternalAssessment {
  maxScore: number | '';
  achievedScore: number | '';
  weight: number; // percentage weight e.g. 20, 25, 30
  enabled: boolean;
}

export interface Subject {
  id: string;
  name: string;
  level: 'SL' | 'HL';
  boundaries: GradeBoundary[];
  papers: Paper[];
  ia: InternalAssessment;
}
